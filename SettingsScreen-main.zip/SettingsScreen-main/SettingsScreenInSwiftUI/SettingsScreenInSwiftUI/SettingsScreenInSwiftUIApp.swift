//
//  SettingsScreenInSwiftUIApp.swift
//  SettingsScreenInSwiftUI
//
//  Created by Krupanshu Sharma on 26/12/22.
//

import SwiftUI

@main
struct SettingsScreenInSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
